By installing or using this font, you are agree to the Product Usage Agreement:

- ONLY for PERSONAL USE. COMMERCIAL USE IS NOT ALLOWED!
  If you use this demo font for commercial use, we will charge a minimum of 250x the price of our commercial license.

- Here is the link to purchase full version:
  *link

- For Corporate use you have to purchase Corporate license

- If you need a custom license please contact us at
katariostudio@gmail.com

- Any donation are very appreciated. Paypal account for donation : https://paypal.me/rz1210

Follow our instagram for update : @katariostudio

Thank you.

-------------------

INDONESIA:

Dengan meng-install font ini, anda dianggap mengerti dan menyetujui semua syarat dan ketentuan penggunaan font dibawah ini:

- Font demo ini hanya dapat digunakan untuk keperluan "Personal Use"/kebutuhan pribadi, atau untuk keperluan yang sifatnya tidak "komersil", alias tidak menghasilkan profit atau keuntungan dari hasil memanfaatkan/menggunakan font kami. Baik itu untuk individu, Agensi Desain Grafis, Percetakan, Distro atau Perusahaan/Korporasi.   

- Silakan gunakan lisensi komersial dengan membeli melalui link ini :
  *link

- Dengan hanya lisensi "Personal Use", DILARANG KERAS menggunakan atau memanfaatkan font ini untuk kepeluan Komersial, baik itu untuk Iklan, Promosi, TV, Film, Video, Motion Graphics, Youtube, Desain kaos distro atau untuk Kemasan Produk (baik Fisik ataupun Digital) atau Media apapun dengan tujuan menghasilkan profit/keuntungan.

- Jika anda kedapatan menggunakan font demo ini untuk tujuan komersil, maka akan kami dendakan minimum 250x harga komersial font.

- Untuk penggunaan keperluan Perusahaan/Korporasi silakan menggunakan Corporate License.

Informasi tentang Lisensi apa yang akan anda butuhkan, silahkan menghubungi kami di : katariostudio@gmail.com

Terima kasih.